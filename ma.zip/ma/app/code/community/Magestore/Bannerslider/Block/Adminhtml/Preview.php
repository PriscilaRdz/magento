<?php

class Magestore_Bannerslider_Block_Adminhtml_Preview extends Mage_Core_Block_Template
{
	/**
	 * prepare block's layout
	 *
	 * @return Magestore_Bannerslider_Block_Bannerslider
	 */
	public function _prepareLayout(){
//            die('sdfsfsdsdfs');
           // 
                parent::_prepareLayout();
              // $this->setTemplate('bannerslider/standardslider.phtml');
	}
}